%---------------------------------------------------------------
% Función que Genera dos señales seno desde un vector de valores
% - Entrada: A
% - Salida: S1,S2
% Autor: VA
% Tesis: Tesis
%---------------------------------------------------------------
function [S1,S2] = Sin2Signal(A)
    S1=sin(A);
    S2=2*sin(A);
end